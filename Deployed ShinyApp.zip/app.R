library(shiny)
library(shinythemes)
library(shinydashboard)
library(dplyr)
library(OpenImageR)
library(rsconnect)

Laptop <- read.csv("df11.csv", header = TRUE, encoding="UTF-8", stringsAsFactors=FALSE)
as.data.frame(Laptop)

ui <- dashboardPage(skin = "purple",
                    dashboardHeader(title = "EasyPC",titleWidth = 350),
                    sidebar <- dashboardSidebar(
                        width=350, 
                        sidebarMenu(
                            menuItem("Introduction", icon = icon("refresh"), tabName = "Introduction",
                                     badgeColor = "green"),
                            menuItem("Selection", tabName = "selection", icon = icon("dashboard"),badgeLabel = "HIT!"),
                            menuItem("Brand", icon = icon("database"), tabName = "Brand",
                                     badgeColor = "green"),
                            menuItem("Price", icon = icon("bar-chart-o"), tabName = "Price",
                                     badgeColor = "green"),
                            
                            menuItem("Size", icon = icon("dashboard"), tabName = "Size",
                                     badgeColor = "green"),
                            
                            menuItem("Type", icon = icon("table"), tabName = "Type",
                                     badgeColor = "green"),
                            menuItem("Weight", icon = icon("database"), tabName = "Weight",
                                     badgeColor = "green"),
                            menuItem("Documentation", icon = icon("refresh"), tabName = "Documentation",
                                     badgeColor = "green")
                        )
                    ),
                    body <- dashboardBody(
                        
                        tabItems(
                            tabItem(tabName="Introduction",
                                    img(src='https://i.ibb.co/RjnG12w/3.jpg', align = "left")),
                            
                            tabItem(tabName="selection",
                                    
                                    fluidPage(
                                        sidebarLayout(
                                            mainPanel(
                                                radioButtons("PriceInput", "Price",choices = unique(Laptop$Price.Filter)),
                                                radioButtons("PurposeInput", "Purpose", choices = unique(Laptop$Purpose.Filter)),
                                                radioButtons("TimeInput", "Time",choices = unique(Laptop$Time.Filter)),
                                                radioButtons("OSInput", "OS",choices = unique(Laptop$OS.Filter))
                                            ),
                                            tableOutput("LaptopRecom")
                                        )
                                    )
                            ),
                            tabItem(tabName = "Brand", 
                                    img(src='https://i.ibb.co/sQXmnbM/Brand.jpg', align = "left")),
                            
                            tabItem(tabName = "Price", 
                                    img(src='https://i.ibb.co/Qd7shfQ/Price.jpg', align = "left")),
                            
                            tabItem(tabName = "Size", 
                                    img(src='https://i.ibb.co/ckw6nn2/Size.jpg', align = "left")),
                            
                            tabItem(tabName = "Type", 
                                    img(src='https://i.ibb.co/61n4xfB/Type.jpg', align = "left")),
                            tabItem(tabName = "Weight", 
                                    img(src='https://i.ibb.co/cDKx4jc/Weight.jpg', align = "left")),
                            tabItem(tabName = "Documentation", 
                                    img(src='https://i.ibb.co/LSsZ7WQ/Documentation.jpg', align = "left"))
                        )))

server <- function(input, output) {
    filtered <- reactive({
        Laptop %>%
            filter(Price.Filter == input$PriceInput
            ) %>%
            filter(Purpose.Filter == input$PurposeInput
            ) %>%
            filter(Time.Filter == input$TimeInput
            ) %>%
            filter(OS.Filter == input$OSInput
            ) %>%
            select(Company, Product, TypeName, Inches, Cpu, Gpu, Weight_KG, Ram_GB, Memory_GB, Price_RM
            )
    })
    
    output$LaptopRecom <- renderTable({
        filtered()
    })
    
}

shinyApp(ui, server)
